
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receive_model extends CI_Model {
	public function __construct(){
		parent::__construct();
		//call model inti 
		$this->load->model('Initdata_model');
	}

	public function get_receive( $start, $limit)
	{

	    $sql =" SELECT p.*  FROM  receive p   ORDER BY p.id DESC  LIMIT " . $start . "," . $limit;
		$re = $this->db->query($sql);
		return $re->result_array();

	}

	public function get_receive_count()
	{
		$sql =" SELECT COUNT(id) as connt_id FROM  receive p"; 
		$query = $this->db->query($sql);
		$row = $query->row_array();
		return  $row['connt_id'];
	
	}


	public function get_receive_id($receive_id)
	{
		$sql ="SELECT * FROM receive WHERE id = '".$receive_id."'"; 

		$query = $this->db->query($sql);
		$row = $query->row_array();
		return $row;
	}


    public function get_receive_search()
	{
		date_default_timezone_set("Asia/Bangkok");
		$data_receive = array(
			'search' => $this->input->post('search')		
		);

		$sql ="SELECT * FROM receive WHERE name LIKE '%".$data_receive['search']."%' OR  description LIKE '%".$data_receive['search']."%' ";
		$re = $this->db->query($sql);
		$return_data['result_receive'] = $re->result_array();
		$return_data['data_search'] = $data_receive;
		$return_data['sql'] = $sql;
		return $return_data;
	}

	public function update_receive($receive_id)
	{
		$slug = $slug =$this->input->post('slug');
		if($this->input->post('slug') == ""){
			$slug =$this->input->post('name');
		}


		date_default_timezone_set("Asia/Bangkok");
		$data_receive = array(
			'name' => $this->input->post('name'),
			'slug' => $this->Initdata_model->slug($slug),
			'description' => $this->input->post('description'),
			'parenttype_id' => $this->input->post('select_type'),
			'modified_date' => date("Y-m-d H:i:s"),
			'is_active' => $this->input->post('isactive')						
		);
		$where = "id = '".$receive_id."'"; 
		$this->db->update("receive", $data_receive, $where);

	}

	public function save_receive()
	{

		$this->db->trans_start(); # Starting Transaction

		$sku_s = $this->input->post('sku');
		$qty_s =$this->input->post('qty');
		$price_s =$this->input->post('price');

		$is_vat_n = 0;
		$is_vat =  $this->input->post('is_vat');
		if($is_vat == 1)
		{
			$is_vat_n = 1;	
		}
		else{
			$is_vat_n = 0;	
		}
		$qty_m = 0; $vat_m = 0; $total_m = 0;
		$i = 0;
		foreach( $this->input->post('sku') as $row) {

		  	$qty_m = $qty_m  + $this->input->post('qty')[$i];

		  	if($is_vat_n ==  1){
		  		$vat_m = $vat_m  + (($this->input->post('qty')[$i]  * $this->input->post('price')[$i] ) * 0.07);
		  	}

		  	$total_m = $total_m  + ($this->input->post('qty')[$i]  * $this->input->post('price')[$i]);
			$i++;
		}

		//receive master
		date_default_timezone_set("Asia/Bangkok");
		$data_receive = array(
			'comment' =>$this->input->post('comment'),
			'do_ref' => $this->input->post('do_ref'),
			'doc_no' =>"RE".date("YmdHis"),
			'qty' => $qty_m,
			'vat' => $vat_m ,
			'total' => $total_m ,
			'create_date' => date("Y-m-d H:i:s"),
			'modified_date' => date("Y-m-d H:i:s"),
			'is_vat' => $is_vat_n,
			'is_active' => $this->input->post('isactive')						
		);
		
		$this->db->insert("receive", $data_receive);
		$insert_id = $this->db->insert_id();

		$i = 0;
		foreach( $this->input->post('sku') as $row) {

		  	$vat = 0;
		  	if($is_vat_n == 1){
		  		$vat = ($this->input->post('qty')[$i]  * $this->input->post('price')[$i] ) * 0.07;
		  	}

		  	$total = $this->input->post('qty')[$i]  * $this->input->post('price')[$i];

		  	date_default_timezone_set("Asia/Bangkok");
			$data_receive_detail = array(
				'receive_id' =>$insert_id ,
				'product_id' => $this->input->post('id')[$i],
				'price' => $this->input->post('price')[$i],
				'qty' => $this->input->post('qty')[$i],
				'vat' => $vat,
				'total' => $total,					
			);
			
			$this->db->insert("receive_detail", $data_receive_detail);
			$i++;
		}

		$this->db->trans_complete(); # Completing transaction
		/*Optional*/

		if ($this->db->trans_status() === FALSE) {
		    # Something went wrong.
		    $this->db->trans_rollback();
		   // return FALSE;
		} 
		else {
		    # Everything is Perfect. 
		    # Committing data to the database.
		    $this->db->trans_commit();
		   // return TRUE;
		}
   		return  $insert_id;

	}

	public function get_product($product_id)
	{
		$sql ="SELECT * FROM products WHERE sku = '".$product_id."'"; 

		$query = $this->db->query($sql);
		$row = $query->row_array();
		return $row;
	}

}

/* End of file receive_model.php */
/* Location: ./application/models/receive_model.php */