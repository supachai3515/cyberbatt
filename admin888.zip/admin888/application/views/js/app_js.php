<script type="text/javascript">
	var app = angular.module("myApp", ['ui.bootstrap']);
	app.controller("myCtrl", function($scope, $http, $uibModal, $log) {
	    $scope.firstName = "John";
	    $scope.lastName = "Doe";
	    $scope.stock_data

	  


	       $scope.getStock = function(product_id) {
            $scope.product_id = product_id
	             $http({
	            method: 'POST',
	            url: '<?php echo base_url('products/getstock');?>',
	             headers: {
	           'Content-Type': 'application/x-www-form-urlencoded'
	         },

	         data: { product_id : $scope.product_id}
	           
	        }).success(function(data) {
	            $scope.items = data;
	            //console.log(data);
	       });

       }



		  $scope.animationsEnabled = true;

		  $scope.open = function (product_id) {
		  	
		    var modalInstance = $uibModal.open({
		      animation: $scope.animationsEnabled,
		      templateUrl: 'myModalContent.html',
		      controller: 'ModalInstanceCtrl',
		      size: "",
		      resolve: {
		        items: function () {
		          return product_id;
		        }
		      }
		    });

		    modalInstance.result.then(function (selectedItem) {
		      $scope.selected = selectedItem;
		    }, function () {
		      $log.info('Modal dismissed at: ' + new Date());
		    });
		  };

		  $scope.toggleAnimation = function () {
		    $scope.animationsEnabled = !$scope.animationsEnabled;
		  };

		   $scope.changeProvince = function() {

		        $http({
		            method: 'POST',
		            url: '<?php echo base_url('special_county/getProvince');?>',
		            headers: {
		                'Content-Type': 'application/x-www-form-urlencoded'
		            },

		            data: {
		                province_id: $scope.province
		            }

		        }).success(function(data) {
		            $scope.items = data;
		            //console.log(data);
		        });
		    };

		//getproduct
		// Code goes here

	  $scope.product_receive = [];
	  $scope.addReceive = function() {
	  	 try {

	      if ($scope.sku.length > 0 && $scope.qty > 0 && $scope.price > 0) {
	          $scope.msgError = "";

	          $http({
	              method: 'POST',
	              url: '<?php echo base_url('receive/get_product');?>',
	              headers: {
	                  'Content-Type': 'application/x-www-form-urlencoded'
	              },

	              data: {
	                  sku: $scope.sku
	              }

	          }).success(function(data) {

	              var product_receive_re = data;

	              try {

	                  if (product_receive_re["sku"].length > 0) {
	                      var vat_p = 0;
	                      if ($scope.is_vat_rececive) {
	                          vat_p = parseInt(($scope.price * $scope.qty) * 0.07);
	                      }

	                      var product_receive = {
	                      	  id: product_receive_re["id"],
	                          sku: product_receive_re["sku"],
	                          name: product_receive_re["name"],
	                          qty: $scope.qty,
	                          price: $scope.price,
	                          vat: vat_p,
	                          total: $scope.qty * $scope.price,
	                      };

	                      if($scope.product_receive.length > 0)
	                      {
	                      	var isdup = 0;
	                      	 angular.forEach($scope.product_receive, function(value,index) {
		                      	if(value.sku == product_receive_re["sku"] ){
		                      		isdup = 1;
		                      		$scope.msgError = "ข้อมูลสินค้า "+product_receive_re["sku"] +" : "+product_receive_re["name"]+" ***ซ้ำ***  กรุณาลบแล้วเพิ่มใหม่";
		                      	}
								  		
							  });

	                      	 if(isdup == 0){
	                      	 		$scope.product_receive.push(product_receive);
	                      	 }
	                      }
	                      else{
	                      	$scope.product_receive.push(product_receive);
	                      }

	                  }

	              } catch (err) {
	                  $scope.msgError = "ไม่มีข้อมูลสินค้า";
	              }
	          });

	      }

	    } catch (err) {
	          $scope.msgError = "กรุณากรอกข้อมูลให้ครบ";
	    }


	  };


	   
	   $scope.removeProduct = function(index){
	    $scope.product_receive.splice(index, 1);
	   };    
		

		$scope.getTotalReceive = function(){
		    var total = 0;
		    for(var i = 0; i < $scope.product_receive.length; i++){
		        var product = $scope.product_receive[i];
		        total += (product.price * product.qty);
		    }
		    return total;
		}
		$scope.getVatReceive = function(){
		    var total = 0;
		    for(var i = 0; i < $scope.product_receive.length; i++){
		        var product = $scope.product_receive[i];
		        total += (product.vat);
		    }
		    return total;
		}

		$scope.getQtyReceive = function(){
		    var total = 0;
		    for(var i = 0; i < $scope.product_receive.length; i++){
		        var product = $scope.product_receive[i];
		        total += (product.qty);
		    }
		    return total;
		}

		


	});


	// Please note that $uibModalInstance represents a modal window (instance) dependency.
	// It is not the same as the $uibModal service used above.

	angular.module('ui.bootstrap').controller('ModalInstanceCtrl', function ($scope,$http, $uibModalInstance, items) {

		$scope.product_id = items
	             $http({
	            method: 'POST',
	            url: '<?php echo base_url('products/getstock');?>',
	             headers: {
	           'Content-Type': 'application/x-www-form-urlencoded'
	         },

	         data: { product_id : $scope.product_id}
	           
	        }).success(function(data) {
	            $scope.items_stock = data;
	            //console.log(data);
	       });


	  $scope.items = items;
	  $scope.selected = {
	    item: $scope.items[0]
	  };

	  $scope.ok = function () {
	    $uibModalInstance.close($scope.selected.item);
	  };

	  $scope.cancel = function () {
	    $uibModalInstance.dismiss('cancel');
	  };

	});

</script>
	