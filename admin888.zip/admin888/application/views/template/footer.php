	<footer>
	    <div class="footer" id="footer">
	    </div>
	    <!--/.footer-->
	    <hr/>
	    <div class="footer-bottom">
	          <p class="text-center"> Copyright ©  wisa-ecommerce All right reserved. Design By <a href="http://www.wisadev.com">www.wisadev.com</a></p>
	    </div>
	    <!--/.footer-bottom--> 
	</footer>
</div><!-- /#wrapper -->
