<?= $this->load->view('template/header'); ?>
<?= $this->load->view('template/navigation'); ?>
<?= $this->load->view($content); ?>
<?= $this->load->view('template/footer'); ?>
<?= $this->load->view('template/script'); ?>